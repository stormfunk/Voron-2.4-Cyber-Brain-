# Voron 2.4 350mm - "Cyber Brain" Pics

This folder contains images of the printer.



![NEON-GENESIS INSPIRED](NEON.jpeg)


---

**Last Updated**: Auto-generated on commit  
